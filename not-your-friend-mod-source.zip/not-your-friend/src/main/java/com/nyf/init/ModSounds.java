package com.nyf.init;

import com.nyf.NotYourFriend;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {

    public static SoundEvent MIMIC_AMBIENCE;
    public static SoundEvent MIMIC_CHASE;
    public static SoundEvent MIMIC_NOTICE;
    public static SoundEvent MIMIC_JUMPSCARE;
    public static SoundEvent MIMIC_REVEAL;
    public static SoundEvent MIMIC_BONE_CRACK;
    public static SoundEvent MIMIC_BONE_CRACK_LONG;
    public static SoundEvent MIMIC_FOOTSTEP;
    public static SoundEvent MIMIC_SNIFF;
    public static SoundEvent MIMIC_RELEASE;

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(NotYourFriend.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void registerSounds() {
        MIMIC_AMBIENCE   = register("entity.mimic.ambience");
        MIMIC_CHASE      = register("entity.mimic.chase");
        MIMIC_NOTICE     = register("entity.mimic.notice");
        MIMIC_JUMPSCARE  = register("entity.mimic.jumpscare");
        MIMIC_REVEAL     = register("entity.mimic.reveal");
        MIMIC_BONE_CRACK = register("entity.mimic.bone_crack");
        MIMIC_BONE_CRACK_LONG = register("entity.mimic.bone_crack_long");
        MIMIC_FOOTSTEP   = register("entity.mimic.footstep");
        MIMIC_SNIFF      = register("entity.mimic.sniff");
        MIMIC_RELEASE    = register("entity.mimic.release");

        NotYourFriend.LOGGER.info("Registered sounds for " + NotYourFriend.MOD_ID);
    }
}
