package com.nyf;

import com.nyf.init.ModEntities;
import com.nyf.init.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NotYourFriend implements ModInitializer {
    public static final String MOD_ID = "not-your-friend";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEntities.registerEntities();
        ModSounds.registerSounds();

        FabricDefaultAttributeRegistry.register(
            ModEntities.MIMIC,
            com.nyf.entity.custom.MimicEntity.createMimicAttributes()
        );

        LOGGER.info("Not Your Friend - Mimic mod loaded!");
    }
}
