package com.nyf;

import com.nyf.entity.client.renderer.MimicRenderer;
import com.nyf.init.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NotYourFriendClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.MIMIC, MimicRenderer::new);
    }
}
