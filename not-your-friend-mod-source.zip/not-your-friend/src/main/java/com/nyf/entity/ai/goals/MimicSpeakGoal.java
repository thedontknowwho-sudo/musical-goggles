package com.nyf.entity.ai.goals;

import com.nyf.entity.custom.MimicEntity;
import com.nyf.init.ModSounds;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.random.Random;

/**
 * Occasionally plays ambient or sniff sounds while the Mimic is disguised,
 * making it feel alive and unsettling.
 * Adapted from SpeakGoal (SPB-Revamped, GPL-3.0, SpacePotato).
 */
public class MimicSpeakGoal extends Goal {
    private final Random random = Random.create();
    private final MimicEntity mimic;
    private int cooldown;

    public MimicSpeakGoal(MimicEntity mimic) {
        this.mimic = mimic;
    }

    @Override
    public boolean canStart() { return mimic.isAlive(); }

    @Override
    public void start() { cooldown = getTickCount(40); }

    @Override
    public void tick() {
        if (mimic.getWorld().isClient || mimic.shouldBeginReveal()) return;
        if (cooldown-- > 0) return;

        int pick = random.nextBetween(1, 3);
        if (pick == 1) {
            mimic.getWorld().playSoundFromEntity(null, mimic, ModSounds.MIMIC_SNIFF,
                SoundCategory.HOSTILE, 2.0f, 1.0f);
        } else if (pick == 2) {
            mimic.getWorld().playSoundFromEntity(null, mimic, ModSounds.MIMIC_AMBIENCE,
                SoundCategory.HOSTILE, 1.5f, 1.0f);
        }

        cooldown = getTickCount(random.nextBetween(100, 300));
    }
}
