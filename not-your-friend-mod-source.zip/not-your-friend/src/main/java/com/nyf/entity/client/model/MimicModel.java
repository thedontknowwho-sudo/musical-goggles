package com.nyf.entity.client.model;

import com.nyf.NotYourFriend;
import com.nyf.entity.custom.MimicEntity;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

public class MimicModel extends GeoModel<MimicEntity> {

    @Override
    public Identifier getModelResource(MimicEntity entity) {
        return new Identifier(NotYourFriend.MOD_ID, "geo/entity/skin_walker_default.geo.json");
    }

    @Override
    public Identifier getTextureResource(MimicEntity entity) {
        return new Identifier(NotYourFriend.MOD_ID, "textures/entity/skinwalker/skin-walker.png");
    }

    @Override
    public Identifier getAnimationResource(MimicEntity entity) {
        return new Identifier(NotYourFriend.MOD_ID, "animations/entity/skinwalker.animation.json");
    }
}
