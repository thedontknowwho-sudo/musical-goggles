package com.nyf.entity.custom;

import com.nyf.entity.ai.goals.*;
import com.nyf.init.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.LookControl;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * MimicEntity - The core "Not Your Friend" entity.
 *
 * A creature that disguises itself as a nearby player and stalks them.
 * When the player looks at it too long, it begins revealing its true form.
 *
 * Adapted from SkinWalkerEntity in SPB-Revamped (GPL-3.0, by SpacePotato).
 * Rewritten for standalone use in the "Not Your Friend" mod.
 */
public class MimicEntity extends HostileEntity implements GeoEntity, GeoAnimatable {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public static final RawAnimation TRANSITION_ANIM =
        RawAnimation.begin().then("transition", Animation.LoopType.PLAY_ONCE);
    public static final RawAnimation IDLE_ANIM =
        RawAnimation.begin().thenLoop("idle");

    // --- State ---
    private UUID targetPlayerUUID;
    private boolean isChasing;
    private boolean isSneaking;
    private boolean trueForm;
    private boolean beginReveal;
    private boolean beginRelease;
    private boolean isNoticing;
    private boolean shouldLookAtTarget = true;
    private boolean shouldActNatural;
    private int suspicion;
    private int maxSuspicion;
    private int revealTicks;
    private int trueFormTime;

    // --- Constructor ---
    public MimicEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.lookControl = new MimicLookControl(this);
        this.maxSuspicion = 1800 + (900 * (world.getPlayers().size() - 1));
        this.targetPlayerUUID = pickTargetPlayer(world);
    }

    // ===================== ATTRIBUTES =====================

    public static DefaultAttributeContainer.Builder createMimicAttributes() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 10000F)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 512.0F)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32f)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0f);
    }

    // ===================== GOALS =====================

    @Override
    protected void initGoals() {
        this.targetSelector.add(2, new MimicTargetGoal(this));
        this.goalSelector.add(4, new MimicSpeakGoal(this));
        this.goalSelector.add(3, new MimicFollowPlayerGoal(this, 5, 15, 1.0f));
        this.goalSelector.add(3, new MimicActNaturalGoal(this));
        this.goalSelector.add(1, new MimicAttackGoal(this));
    }

    // ===================== TICK =====================

    @Override
    public void tick() {
        if (!this.getWorld().isClient) {
            // Track chasing state
            boolean hasTarget = this.getTarget() != null;
            if (hasTarget != isChasing) {
                isChasing = hasTarget;
            }

            // Disguise phase: watch suspicion and time
            if (!trueForm && !beginReveal) {
                if (this.age >= 2400 || suspicion > maxSuspicion) {
                    beginReveal = true;
                }
                this.updateSuspicionFromPlayers();
            }

            // True form timer — release after 60 seconds
            if (trueForm && !beginRelease) {
                trueFormTime++;
                if (trueFormTime >= 1200) {
                    beginRelease = true;
                    this.discard();
                }
            }

            // Reveal sequence tick
            if (beginReveal) {
                tickReveal();
            }
        }
        super.tick();
    }

    /** Ticks through the dramatic reveal sequence with sound cues */
    private void tickReveal() {
        this.setTarget(null);
        this.getNavigation().stop();
        revealTicks++;

        if (revealTicks == 9) {
            this.playSound(ModSounds.MIMIC_BONE_CRACK, 10.0f, 1.0f);
        }
        if (revealTicks == 39) {
            this.playSound(ModSounds.MIMIC_BONE_CRACK_LONG, 10.0f, 1.0f);
        }
        if (revealTicks == 99) {
            this.getWorld().playSoundFromEntity(null, this, ModSounds.MIMIC_REVEAL,
                SoundCategory.HOSTILE, 100.0f, 1.0f);
        }
        if (revealTicks >= 220) {
            beginReveal = false;
            trueForm = true;
            this.setInvulnerable(true);

            // Resume targeting the closest player
            List<? extends PlayerEntity> nearby = this.getWorld().getPlayers();
            if (!nearby.isEmpty()) {
                this.beginTargeting(nearby.get(0));
            }

            revealTicks = 0;
        }
    }

    /** Increases suspicion when players stare at the mimic */
    private void updateSuspicionFromPlayers() {
        List<? extends PlayerEntity> nearbyPlayers = this.getWorld().getPlayers(
            net.minecraft.entity.ai.TargetPredicate.DEFAULT, this,
            new Box(this.getPos(), this.getPos().add(15, 15, 15)).offset(-7.5, -7.5, -7.5)
        );
        for (PlayerEntity player : nearbyPlayers) {
            Vec3d look = player.getRotationVec(1.0f);
            Vec3d toMimic = this.getPos().subtract(player.getPos()).normalize();
            double dot = look.dotProduct(toMimic);
            if (dot > 0.95) {
                this.suspicion++;
            }
        }
    }

    // ===================== TARGETING =====================

    private UUID pickTargetPlayer(World world) {
        List<? extends PlayerEntity> players = world.getPlayers();
        if (players.isEmpty()) return null;
        int idx = players.size() == 1 ? 0 : Random.create().nextBetween(0, players.size() - 1);
        return players.get(idx).getUuid();
    }

    public void noticePlayer(PlayerEntity player) {
        isNoticing = true;
        ScheduledExecutorService svc = Executors.newSingleThreadScheduledExecutor();
        this.playSound(ModSounds.MIMIC_NOTICE, 10.0f, 1.0f);
        this.getLookControl().lookAt(player, 10);
        svc.schedule(() -> {
            this.setTarget(player);
            isNoticing = false;
            svc.shutdown();
        }, 4300, TimeUnit.MILLISECONDS);
    }

    public void beginTargeting(PlayerEntity player) {
        this.getLookControl().lookAt(player, 10);
        this.setTarget(player);
    }

    // ===================== COMBAT =====================

    @Override
    public boolean onKilledOther(ServerWorld world, LivingEntity other) {
        this.setTarget(null);
        this.getNavigation().stop();
        beginRelease = true;
        return super.onKilledOther(world, other);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean hit = super.damage(source, amount);
        if (!this.getWorld().isClient && hit && source.getAttacker() instanceof PlayerEntity) {
            this.suspicion += 100;
        }
        return hit;
    }

    // ===================== SOUND =====================

    @Override
    protected @Nullable SoundEvent getAmbientSound() {
        return ModSounds.MIMIC_AMBIENCE;
    }

    // ===================== HEAD ROTATION =====================

    @Override
    protected float turnHead(float bodyRot, float headRot) {
        if (this.handSwingProgress > 0.0F) bodyRot = this.getHeadYaw();
        float f = MathHelper.wrapDegrees(bodyRot - this.bodyYaw);
        this.bodyYaw += f * 0.3F;
        float g = MathHelper.wrapDegrees(this.getHeadYaw() - this.bodyYaw);
        if (Math.abs(g) > 50.0F) {
            this.bodyYaw += g - (float)(MathHelper.sign(g) * 50);
        }
        boolean bl = g < -90.0F || g >= 90.0F;
        if (bl) headRot *= -1.0F;
        return headRot;
    }

    @Override public int getMaxLookYawChange() { return 360; }
    @Override public int getMaxLookPitchChange() { return 360; }

    // ===================== NBT =====================

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("isSneaking", isSneaking);
        nbt.putBoolean("isChasing", isChasing);
        nbt.putBoolean("trueForm", trueForm);
        nbt.putBoolean("beginReveal", beginReveal);
        nbt.putInt("suspicion", suspicion);
        if (targetPlayerUUID != null) nbt.putUuid("targetPlayer", targetPlayerUUID);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        isSneaking   = nbt.getBoolean("isSneaking");
        isChasing    = nbt.getBoolean("isChasing");
        trueForm     = nbt.getBoolean("trueForm");
        beginReveal  = nbt.getBoolean("beginReveal");
        suspicion    = nbt.getInt("suspicion");
        if (nbt.containsUuid("targetPlayer")) targetPlayerUUID = nbt.getUuid("targetPlayer");
        this.setInvulnerable(trueForm);
    }

    // ===================== GECKOLIB ANIMATIONS =====================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 10, state -> {
            if (beginReveal) return state.setAndContinue(TRANSITION_ANIM);
            state.resetCurrentAnimation();
            return state.setAndContinue(IDLE_ANIM);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    // ===================== STATE GETTERS/SETTERS (for goals) =====================

    public UUID getTargetPlayerUUID() { return targetPlayerUUID; }
    public void setTargetPlayerUUID(UUID uuid) { this.targetPlayerUUID = uuid; }

    public boolean isChasing() { return isChasing; }
    public boolean isSneaking() { return isSneaking; }
    public void setSneaking(boolean sneaking) { this.isSneaking = sneaking; }
    public boolean isInTrueForm() { return trueForm; }
    public boolean shouldBeginReveal() { return beginReveal; }
    public boolean shouldActNatural() { return shouldActNatural; }
    public void setShouldActNatural(boolean v) { shouldActNatural = v; }
    public boolean isNoticing() { return isNoticing; }
    public boolean shouldLookAtTarget() { return shouldLookAtTarget; }
    public void setShouldLookAtTarget(boolean v) { shouldLookAtTarget = v; }
    public void addSuspicion(int amount) { suspicion += amount; }
    public void addSuspicion() { suspicion += 1; }
    public int getSuspicion() { return suspicion; }

    // ===================== LOOK CONTROL =====================

    public class MimicLookControl extends LookControl {
        public MimicLookControl(MobEntity entity) { super(entity); }

        public void lookAt(Vec3d vec, int timer) {
            this.x = vec.x; this.y = vec.y; this.z = vec.z;
            this.maxYawChange = 360f; this.maxPitchChange = 360f;
            this.lookAtTimer = timer;
        }

        @Override
        public void tick() {
            if (this.lookAtTimer > 0) {
                this.lookAtTimer--;
                this.getTargetYaw().ifPresent(yaw ->
                    this.entity.headYaw = this.changeAngle(this.entity.headYaw, yaw, this.maxYawChange));
                this.getTargetPitch().ifPresent(pitch ->
                    this.entity.setPitch(this.changeAngle(this.entity.getPitch(), pitch, this.maxPitchChange)));
            } else {
                this.entity.headYaw = this.changeAngle(this.entity.headYaw, this.entity.bodyYaw, 10f);
            }
            this.clampHeadYaw();
        }
    }
}
