package com.nyf.entity.ai.goals;

import com.nyf.entity.custom.MimicEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

import java.util.List;

/**
 * Makes the Mimic loosely follow a nearby player while disguised,
 * keeping just close enough to be creepy.
 * Adapted from FollowClosestPlayerGoal (SPB-Revamped, GPL-3.0, SpacePotato).
 */
public class MimicFollowPlayerGoal extends Goal {
    private final MimicEntity mimic;
    private final double minDist;
    private final double maxDist;
    private final double speed;
    private PlayerEntity followTarget;

    public MimicFollowPlayerGoal(MimicEntity mimic, double minDist, double maxDist, double speed) {
        this.mimic = mimic;
        this.minDist = minDist;
        this.maxDist = maxDist;
        this.speed = speed;
    }

    @Override
    public boolean canStart() {
        if (mimic.isInTrueForm() || mimic.shouldBeginReveal()) return false;
        if (mimic.getTargetPlayerUUID() == null) return false;
        List<? extends PlayerEntity> players = mimic.getWorld().getPlayers();
        for (PlayerEntity p : players) {
            if (p.getUuid().equals(mimic.getTargetPlayerUUID())) {
                followTarget = p;
                double dist = mimic.squaredDistanceTo(p);
                return dist > (minDist * minDist) && dist < (maxDist * maxDist);
            }
        }
        return false;
    }

    @Override
    public void tick() {
        if (followTarget == null || !followTarget.isAlive()) return;
        double dist = mimic.squaredDistanceTo(followTarget);
        if (dist > (minDist * minDist)) {
            mimic.getNavigation().startMovingTo(followTarget, speed);
            mimic.setShouldActNatural(false);
        } else {
            mimic.getNavigation().stop();
            mimic.setShouldActNatural(true);
        }
    }

    @Override
    public void stop() {
        mimic.getNavigation().stop();
        followTarget = null;
    }
}
