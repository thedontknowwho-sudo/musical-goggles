package com.nyf.entity.ai.goals;

import com.nyf.entity.custom.MimicEntity;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;

/**
 * Makes the Mimic attack when in its true form.
 */
public class MimicAttackGoal extends MeleeAttackGoal {
    private final MimicEntity mimic;

    public MimicAttackGoal(MimicEntity mimic) {
        super(mimic, 1.2, false);
        this.mimic = mimic;
    }

    @Override
    public boolean canStart() {
        return mimic.isInTrueForm() && super.canStart();
    }
}
