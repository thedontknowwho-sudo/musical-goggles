package com.nyf.entity.client.renderer;

import com.nyf.NotYourFriend;
import com.nyf.entity.client.model.MimicModel;
import com.nyf.entity.custom.MimicEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * Renders the MimicEntity using GeckoLib.
 * When in disguise, it renders a player-skin overlay (placeholder texture).
 * When in true form, it switches to the true-form model and textures.
 */
public class MimicRenderer extends GeoEntityRenderer<MimicEntity> {

    private static final Identifier TRUE_FORM_TEXTURE =
        new Identifier(NotYourFriend.MOD_ID, "textures/entity/skinwalker/final_form_head_texture.png");
    private static final Identifier DISGUISE_TEXTURE =
        new Identifier(NotYourFriend.MOD_ID, "textures/entity/skinwalker/placeholder.png");

    public MimicRenderer(EntityRendererFactory.Context context) {
        super(context, new MimicModel());
    }

    @Override
    public Identifier getTextureLocation(MimicEntity entity) {
        if (entity.isInTrueForm()) {
            return TRUE_FORM_TEXTURE;
        }
        return DISGUISE_TEXTURE;
    }
}
