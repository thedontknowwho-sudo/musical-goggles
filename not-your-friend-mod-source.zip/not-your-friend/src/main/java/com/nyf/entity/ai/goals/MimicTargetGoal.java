package com.nyf.entity.ai.goals;

import com.nyf.entity.custom.MimicEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Makes the Mimic pursue a player target once in true form.
 */
public class MimicTargetGoal extends ActiveTargetGoal<PlayerEntity> {
    private final MimicEntity mimic;

    public MimicTargetGoal(MimicEntity mimic) {
        super(mimic, PlayerEntity.class, true);
        this.mimic = mimic;
    }

    @Override
    public boolean canStart() {
        return mimic.isInTrueForm() && super.canStart();
    }
}
