package com.nyf.entity.ai.goals;

import com.nyf.entity.custom.MimicEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

/**
 * Makes the Mimic perform random player-like actions while in disguise:
 * sneaking, strafing, looking around, swinging arms.
 * Directly adapted from ActNaturalGoal (SPB-Revamped, GPL-3.0, SpacePotato).
 */
public class MimicActNaturalGoal extends Goal {
    private final Random random = Random.create(7585889L);
    private final java.util.Random rand = new java.util.Random();
    private final MimicEntity mimic;

    private Integer currentAction;
    private int actCooldown;
    private int actionCount;
    private int actionCooldown;
    private boolean actionSwitch;
    private Vec3d randLookDir;

    public MimicActNaturalGoal(MimicEntity mimic) {
        this.mimic = mimic;
    }

    @Override
    public boolean canStart() {
        return mimic.shouldActNatural() && !mimic.isInTrueForm() && !mimic.shouldBeginReveal();
    }

    @Override
    public void start() { actCooldown = getTickCount(40); }

    @Override
    public void stop() {
        currentAction = null;
        mimic.setSneaking(false);
        actionCooldown = 0; actionCount = 0; actCooldown = 0;
    }

    @Override
    public void tick() {
        if (mimic.getWorld().isClient) return;
        if (actCooldown-- > 0) return;

        if (currentAction == null) currentAction = random.nextBetween(1, 4);

        switch (currentAction) {
            case 1 -> sneakTick();
            case 2 -> strafeTick();
            case 3 -> lookAndPunchTick();
            case 4 -> lookMultTick();
        }
    }

    private void sneakTick() {
        if (actionCooldown-- > 0) return;
        if (actionCount < 2 && !mimic.isSneaking()) {
            mimic.setSneaking(true); actionCount++;
        } else if (mimic.isSneaking()) {
            mimic.setSneaking(false);
        } else {
            resetAction();
        }
    }

    private void strafeTick() {
        if (actionCooldown-- > 0) return;
        if (actionCount < 8 && !actionSwitch) {
            mimic.sidewaysSpeed = 0.2f; actionSwitch = true; actionCount++; actionCooldown = 2;
        } else if (actionSwitch) {
            mimic.sidewaysSpeed = -0.2f; actionSwitch = false; actionCount++; actionCooldown = 2;
        } else {
            mimic.sidewaysSpeed = 0; actionSwitch = false; resetAction();
        }
    }

    private void lookAndPunchTick() {
        mimic.setShouldLookAtTarget(false);
        if (randLookDir == null) {
            randLookDir = eulerToVector(rand.nextFloat(-45, 45), rand.nextFloat(-180, 180));
            ((MimicEntity.MimicLookControl) mimic.getLookControl()).lookAt(randLookDir, 5);
        }
        if (actionCooldown-- > 0) return;
        if (actionCount < 4) {
            mimic.swingHand(Hand.MAIN_HAND); actionCount++; actionCooldown = 2;
        } else {
            mimic.setShouldLookAtTarget(true); randLookDir = null; resetAction();
        }
    }

    private void lookMultTick() {
        mimic.setShouldLookAtTarget(false);
        if (actionCooldown-- > 0) return;
        if (actionCount < 5) {
            ((MimicEntity.MimicLookControl) mimic.getLookControl())
                .lookAt(eulerToVector(rand.nextFloat(-45, 45), rand.nextFloat(-180, 180)),
                        random.nextBetween(4, 9));
            if (random.nextBetween(1, 3) == 1) mimic.swingHand(Hand.MAIN_HAND);
            actionCount++; actionCooldown = random.nextBetween(6, 12);
        } else {
            mimic.setShouldLookAtTarget(true); resetAction();
        }
    }

    private void resetAction() {
        currentAction = null; actionCount = 0;
        actCooldown = getTickCount(random.nextBetween(60, 150));
    }

    private Vec3d eulerToVector(float pitch, float yaw) {
        float x = MathHelper.cos(yaw) * MathHelper.cos(pitch);
        float y = MathHelper.sin(yaw) * MathHelper.cos(pitch);
        float z = MathHelper.sin(pitch);
        return new Vec3d(x, y, z).multiply(180 / Math.PI);
    }
}
